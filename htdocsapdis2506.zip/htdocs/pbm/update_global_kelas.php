<?php
session_start();
include "config.php";

// Proteksi keamanan admin
if (!isset($_SESSION['username']) || $_SESSION['level_user'] !== 'admin') {
    die(json_encode(['status' => 'error', 'message' => 'Akses ditolak!']));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputData = json_decode(file_get_contents("php://input"), true);

    if (isset($inputData['data_kelas']) && is_array($inputData['data_kelas'])) {
        $sukses = true;
        
        foreach ($inputData['data_kelas'] as $item) {
            $id_kelas   = mysqli_real_escape_string($con, $item['id_kelas']);
            $kode_kelas = mysqli_real_escape_string($con, $item['kode_kelas']);
            $nama_kelas = mysqli_real_escape_string($con, $item['nama_kelas']);
            $wali_kelas = mysqli_real_escape_string($con, $item['wali_kelas']);
            
            if (!empty($id_kelas)) {
                // Proses update data termasuk kolom wali_kelas baru
                $query_string = "UPDATE master_kelas SET 
                                 `kode_kelas` = '$kode_kelas', 
                                 `nama_kelas` = '$nama_kelas',
                                 `wali_kelas` = '$wali_kelas'
                                 WHERE `id_kelas` = '$id_kelas'";
                                 
                if (!mysqli_query($con, $query_string)) {
                    $sukses = false;
                }
            }
        }
        
        if ($sukses) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui beberapa data kelas.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Metode request salah.']);
}
?>
