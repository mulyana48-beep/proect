<?php
include "config.php"; 
include "header.php"; 

// Fungsi mendapatkan nama hari kecil (senin, selasa, dst) berdasarkan format tanggal
function hitungHariIndo($tgl) {
    $daftar_hari = array('Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu');
    $indeks = date('w', strtotime($tgl));
    return $daftar_hari[$indeks];
}

// 1. Pastikan session nama_user dan kode kelas otomatis sudah siap seperti di form.php
$nama_user_sekarang = isset($_SESSION['nama_user']) ? $_SESSION['nama_user'] : '';
$kode_kelas_otomatis = ""; 

if (!empty($nama_user_sekarang) && $con) {
    $nama_user_safe = mysqli_real_escape_string($con, $nama_user_sekarang);
    $query_kelas = "SELECT kode_kelas FROM master_kelas WHERE nama_kelas = '$nama_user_safe'";
    $result_kelas = mysqli_query($con, $query_kelas);
    if ($result_kelas && mysqli_num_rows($result_kelas) > 0) {
        $row_kelas = mysqli_fetch_assoc($result_kelas);
        $kode_kelas_otomatis = $row_kelas['kode_kelas'];
    }
}

// Tendang user jika tidak memiliki akses kelas (keamanan dasar)
if (empty($kode_kelas_otomatis)) {
    echo "<div style='padding: 20px; color: red; text-align: center;'>Akses Ditolak! Kelas Anda tidak teridentifikasi.</div>";
    exit();
}

// 2. Ambil data dari tabel 'catat' KHUSUS untuk kelas user yang sedang login
$kelas_safe = mysqli_real_escape_string($con, $kode_kelas_otomatis);
$query_riwayat = "SELECT * FROM catat WHERE kelas = '$kelas_safe' ORDER BY dibuat_pada DESC";
$result_riwayat = mysqli_query($con, $query_riwayat);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Jurnal Kelas</title>

</head>
<body>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f9; color: #333; padding: 0; }
        .container { max-width: 100%; margin: 1px 0 auto; background: #fff; padding: 25px; border-radius: 0; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        h2 { color: #2c3e50; margin-bottom: 5px; }
        .sub-title { color: #7f8c8d; font-size: 14px; margin-bottom: 25px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 12px 15px; text-align: center; border-bottom: 1px solid #eef2f5; }
        th { background-color: #f8f9fa; color: #34495e; font-weight: 600; }
        tr:hover { background-color: #fcfcfc; }
        /* Badge Status Bulat */
        .badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; color: white; display: inline-block; min-width: 25px; }
        .badge-p { background-color: #4a90e2; }
        .badge-t { background-color: #f39c12; }
        .badge-k { background-color: #e74c3c; }
        .badge-kosong { background-color: #bdc3c7; color: #333; }
        .alert-info { background-color: #e8f4fd; color: #2b73b6; padding: 15px; border-radius: 8px; text-align: center; font-weight: 500; }
    </style>
<div class="container">
    <h2>Riwayat Pengiriman Jurnal KBM</h2>
    <div class="sub-title">Menampilkan log penginputan data harian untuk kelas: <strong><?php echo htmlspecialchars($nama_user_sekarang); ?></strong></div>

    <div class="table-responsive">
        <?php if (mysqli_num_rows($result_riwayat) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <!-- Menambahkan 3 kolom kontrol awal yang di-span secara vertikal -->
                        <th rowspan="2" style="vertical-align: middle; width: 60px;">No</th>
                        <th rowspan="2" style="vertical-align: middle; width: 120px;">Hari</th>
                        <th rowspan="2" style="vertical-align: middle; width: 130px;">Tanggal</th>
                        <th colspan="10">Status Pembelajaran per Jam</th>
                    </tr>
                    <tr>
                        <?php for($j=1; $j<=10; $j++) echo "<th>".sprintf("%02d", $j)."</th>"; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1; // Inisialisasi nomor baris tabel awal
                    while ($row = mysqli_fetch_assoc($result_riwayat)): 
                        $nama_hari = hitungHariIndo($row['tanggal']); // Konversi tanggal ke Hari Indonesia
                    ?>
                        <tr>
                            <!-- Kolom 1: Nomor Urut -->
                            <td style="color: #7f8c8d; font-weight: 500;"><?php echo $no++; ?></td>
                            
                            <!-- Kolom 2: Hari -->
                            <td style="font-weight: 500; color: #34495e;"><?php echo $nama_hari; ?></td>
                            
                            <!-- Kolom 3: Tanggal -->
                            <td style="font-weight: 600; color: #2c3e50;">
                                <?php echo date('d-m-Y', strtotime($row['tanggal'])); ?>
                            </td>
                            
                            <!-- Looping Tampilan Kolom sjam_ke_01 sampai sjam_ke_10 -->
                            <?php for ($i = 1; $i <= 10; $i++): 
                                $num = sprintf("%02d", $i);
                                $status = $row["sjam_ke_$num"];
                                $mapel = htmlspecialchars($row["jam_ke_$num"]);
                                
                                // Tentukan warna badge berdasarkan huruf status
                                $class_badge = "badge-kosong";
                                if ($status == "P") { $class_badge = "badge-p"; }
                                elseif ($status == "T") { $class_badge = "badge-t"; }
                                elseif ($status == "K") { $class_badge = "badge-k"; }
                            ?>
                                <td>
                                    <?php if (!empty($mapel)): ?>
                                        <!-- Menampilkan status berupa huruf ringkas, dengan title hover nama mapel -->
                                        <span class="badge <?php echo $class_badge; ?>" title="Mata Pelajaran: <?php echo $mapel; ?>">
                                            <?php echo !empty($status) ? $status : '-'; ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ccc;">-</span>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert-info">Belum ada data jurnal yang dikirimkan untuk kelas ini.</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
