<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Proteksi halaman: jika session username tidak ada, tendang ke login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!-- Bagian CSS Navbar -->
<style>
    body {
    display: flex !important;
    flex-direction: column !important;
    align-items: stretch !important;
}
    
    .navbar-brand, .nav-links a { text-decoration: none; }
    
    .main-navbar {
        background-color: #ffffff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        padding: 1% 1%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        width: 100%; /* Memaksa navbar memenuhi layar atas */
        box-sizing: border-box;
    }

    .navbar-brand {
        color: #333333;
        font-size: 20px;
        font-weight: 700;
        letter-spacing: 0.5px;
    }

    .navbar-brand span {
        color: #4a90e2;
    }

    .nav-links {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .nav-links a {
        color: #666666;
        font-size: 15px;
        font-weight: 500;
        padding: 8px 12px;
        border-radius: 6px;
        transition: all 0.3s ease;
    }

    .nav-links a:hover {
        color: #4a90e2;
        background-color: rgba(74, 144, 226, 0.08);
    }

    .user-info {
        font-size: 14px;
        color: #888888;
        padding-right: 15px;
        border-right: 1px solid #eeeeee;
    }

    .user-info strong {
        color: #333333;
    }

    .btn-logout {
        background-color: #ffebee;
        color: #c62828 !important;
    }

    .btn-logout:hover {
        background-color: #ef5350 !important;
        color: #ffffff !important;
    }

    @media (max-width: 768px) {
        .main-navbar {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
        .nav-links {
            flex-direction: column;
            gap: 5px;
            width: 100%;
        }
        .user-info {
            border-right: none;
            padding-right: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #eeeeee;
            width: 100%;
        }
    }
</style>

<nav class="main-navbar">
    <a href="form.php" class="navbar-brand">Jurnal<span>KBM</span></a>

    <div class="nav-links">
        <span class="user-info">
            Halo, <strong><?php echo htmlspecialchars($_SESSION['nama_user']); ?></strong> 
            (<?php echo ucfirst(htmlspecialchars($_SESSION['level_user'])); ?>)
        </span>
        <?php if ($_SESSION['level_user'] == 'user_kelas'): ?>
        <a href="form.php">Isi Jurnal</a>
        <a href="riwayat.php">Riwayat</a>
        <?php endif; ?>
        <?php if ($_SESSION['level_user'] == 'admin'): ?>
        <a href="admin_riwayat.php"style="color: #4a90e2; font-weight: 600;">Riwayat Input</a>
        <a href="rekap_kelas.php"style="color: #4a90e2; font-weight: 600;">Rekap Perkelas</a>
        <a href="rekap_guru.php"style="color: #4a90e2; font-weight: 600;">Rekap Mata Pelajaran</a>
        <a href="kelola_kelas.php"style="color: #4a90e2; font-weight: 600;">Kelola Data Kelas</a>
        <a href="kelola_jadwal.php" style="color: #4a90e2; font-weight: 600;">Kelola Jadwal</a>
        <a href="index.php" style="color: #4a90e2; font-weight: 600;">Kelola User</a>

        <?php endif; ?>

        <a href="logout.php" class="btn-logout">Keluar</a>
    </div>
</nav>
