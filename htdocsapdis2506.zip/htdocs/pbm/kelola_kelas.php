<?php 
include 'header.php'; 
include 'config.php'; 

// Proteksi Khusus Admin
if (!isset($_SESSION['level_user']) || $_SESSION['level_user'] !== 'admin') {
    echo "<script>alert('Akses Khusus Admin!'); window.location.href='form.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Master Kelas</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; }
        body { background-color: #f4f6f9; color: #333; }
        .main-content { display: flex; justify-content: center; align-items: center; padding: 20px 20px; width: 100%; }
        .kelola-container { background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; max-width: 900px; }
        .header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; gap: 15px; flex-wrap: wrap; }
        h2 { color: #2c3e50; font-size: 24px; font-weight: 600; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 14px; transition: 0.2s; }
        .btn-mode-edit { background-color: #3498db; color: white; }
        .btn-mode-edit:hover { background-color: #2980b9; }
        .btn-simpan-semua { background-color: #2ecc71; color: white; display: none; }
        .btn-simpan-semua:hover { background-color: #27ae60; }
        .btn-batal { background-color: #95a5a6; color: white; display: none; margin-right: 10px; }
        .btn-batal:hover { background-color: #7f8c8d; }
        .table-responsive { width: 100%; overflow-x: auto; margin-top: 15px; border-radius: 8px; border: 1px solid #eef2f5; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 1px 4px !important; text-align: left; border-bottom: 1px solid #eef2f5; font-size: 14px; }
        th { background-color: #2c3e50; color: white; font-weight: 600; text-transform: uppercase; font-size: 13px; padding: 12px 15px !important; }
        tr:hover { background-color: #f8fafd; }
        .input-inline { width: 100%; padding: 1px 4px !important; margin: 0 !important; height: 26px; line-height: 24px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; outline: none; box-sizing: border-box; }
        .input-inline:focus { border-color: #3498db; background-color: #fff; }
        .nav-link { display: inline-block; margin-top: 25px; color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 14px; }
        .nav-link:hover { text-decoration: underline; }
        .info-kosong { text-align: center; color: #7f8c8d; padding: 40px; font-style: italic; }
        @media (max-width: 600px) { .header-section { flex-direction: column; align-items: stretch; text-align: center; gap: 15px; } .btn { width: 100%; } }
    </style>
</head>
<body>

<div class="main-content">
    <div class="kelola-container">
        <div class="header-section">
            <h2>Kelola Master Data Kelas</h2>
            <div>
                <button type="button" id="btnBatal" class="btn btn-batal" onclick="batalEditKelas()">Batal</button>
                <button type="button" id="btnMode" class="btn btn-mode-edit" onclick="aktifkanModeEditKelas()">Mode Edit</button>
                <button type="button" id="btnSimpan" class="btn btn-simpan-semua" onclick="simpanPerubahanKelas()">Simpan Semua</button>
            </div>
        </div>
        
        <?php
        $query_kelas = "SELECT id_kelas, kode_kelas, nama_kelas, wali_kelas FROM master_kelas ORDER BY kode_kelas ASC";
        $eksekusi_kelas = mysqli_query($con, $query_kelas);
        if ($eksekusi_kelas && mysqli_num_rows($eksekusi_kelas) > 0): 
        ?>
            <div class="table-responsive">
                <table id="tabelKelas">
                    <thead>
                        <tr>
                            <th style="width: 7%; text-align: center;">No</th>
                            <th style="width: 20%; padding-left: 15px !important;">Kode Kelas</th>
                            <th style="width: 23%;">Nama Kelas</th>
                            <th style="width: 50%;">Wali Kelas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($eksekusi_kelas)): 
                        ?>
                            <tr class="baris-kelas" data-id="<?php echo $row['id_kelas']; ?>">
                                <td style="text-align: center; color: #7f8c8d; font-weight: 500;"><?php echo $no++; ?></td>
                                <td class="edit-kode" data-asli="<?php echo htmlspecialchars($row['kode_kelas']); ?>" style="font-weight: bold; color: #7f8c8d; padding-left: 15px !important;">
                                    <?php echo htmlspecialchars($row['kode_kelas']); ?>
                                </td>
                                <td class="edit-nama" data-asli="<?php echo htmlspecialchars($row['nama_kelas']); ?>" style="font-weight: 600; color: #2c3e50;">
                                    <?php echo htmlspecialchars($row['nama_kelas']); ?>
                                </td>
                                <td class="edit-wali" data-asli="<?php echo htmlspecialchars($row['wali_kelas']); ?>">
                                    <?php echo htmlspecialchars($row['wali_kelas']); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="info-kosong">Belum ada data master kelas yang terdaftar di database.</p>
        <?php endif; ?>
    </div>
</div>

<!-- MEMANGGIL FILE JAVASCRIPT EKSTERNAL -->
<script src="kelola_kelas.js"></script>
</body>
</html>
