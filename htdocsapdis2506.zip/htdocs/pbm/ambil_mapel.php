<?php
session_start();
include "config.php";

function hitungHariIndo($tgl) {
    $daftar_hari = array('minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu');
    $indeks = date('w', strtotime($tgl));
    return $daftar_hari[$indeks];
}

$tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$kelas = isset($_GET['kelas']) ? mysqli_real_escape_string($con, $_GET['kelas']) : '';

$respon = [];

if (!empty($tanggal) && !empty($kelas) && $con) {
    $hari = hitungHariIndo($tanggal);
    
    for ($i = 1; $i <= 10; $i++) {
        $num = sprintf("%02d", $i);
        $kriteria_hari_jam = $hari . "_" . $num;
        
        // MENGGUNAKAN JOIN: Menghubungkan tabel jadwal dengan tabel mapel_guru berdasarkan KODE MAPEL
        $query_jdl = "SELECT mg.mapel AS nama_mapel_asli 
                      FROM jadwal j
                      INNER JOIN mapel_guru mg ON j.`$kelas` = mg.kode
                      WHERE j.hari_jam = '$kriteria_hari_jam' 
                      LIMIT 1";
                      
        $eksekusi_jdl = mysqli_query($con, $query_jdl);
        
        if ($eksekusi_jdl && mysqli_num_rows($eksekusi_jdl) > 0) {
            $data_jdl = mysqli_fetch_assoc($eksekusi_jdl);
            // Ambil kolom nama_mapel_asli hasil dari relasi JOIN
            $respon[$num] = !empty(trim($data_jdl['nama_mapel_asli'])) ? trim($data_jdl['nama_mapel_asli']) : '-';
        } else {
            $respon[$num] = '-';
        }
    }
}

// Kirimkan data ke JavaScript dalam bentuk JSON
header('Content-Type: application/json');
echo json_encode($respon);
?>
