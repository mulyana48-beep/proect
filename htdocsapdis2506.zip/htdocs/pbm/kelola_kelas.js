// 1. Mengubah seluruh baris sel kelas menjadi input text (Termasuk kolom wali)
function aktifkanModeEditKelas() {
    document.querySelectorAll('.baris-kelas').forEach(baris => {
        const cKode = baris.querySelector('.edit-kode');
        const cNama = baris.querySelector('.edit-nama');
        const cWali = baris.querySelector('.edit-wali');

        cKode.innerHTML = `<input type="text" class="input-inline" value="${cKode.innerText.trim()}">`;
        cNama.innerHTML = `<input type="text" class="input-inline" value="${cNama.innerText.trim()}">`;
        cWali.innerHTML = `<input type="text" class="input-inline" value="${cWali.innerText.trim()}">`;
    });

    document.getElementById('btnMode').style.display = 'none';
    document.getElementById('btnBatal').style.display = 'inline-block';
    document.getElementById('btnSimpan').style.display = 'inline-block';
}

// 2. Membatalkan pengeditan massal dan mengembalikan teks semula
function batalEditKelas() {
    document.querySelectorAll('.baris-kelas').forEach(baris => {
        const cKode = baris.querySelector('.edit-kode');
        const cNama = baris.querySelector('.edit-nama');
        const cWali = baris.querySelector('.edit-wali');

        cKode.innerHTML = cKode.getAttribute('data-asli');
        cNama.innerHTML = cNama.getAttribute('data-asli');
        cWali.innerHTML = cWali.getAttribute('data-asli');
    });

    document.getElementById('btnMode').style.display = 'inline-block';
    document.getElementById('btnBatal').style.display = 'none';
    document.getElementById('btnSimpan').style.display = 'none';
}

// 3. Mengemas seluruh data (id, kode, nama, wali) ke dalam paket JSON
function simpanPerubahanKelas() {
    const semuaBaris = document.querySelectorAll('.baris-kelas');
    let dataPaketKelas = [];

    semuaBaris.forEach(baris => {
        const id_kelas = baris.getAttribute('data-id');
        const kode_kelas = baris.querySelector('.edit-kode input').value.trim();
        const nama_kelas = baris.querySelector('.edit-nama input').value.trim();
        const wali_kelas = baris.querySelector('.edit-wali input').value.trim();

        dataPaketKelas.push({ id_kelas, kode_kelas, nama_kelas, wali_kelas });
    });

    fetch('update_global_kelas.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_kelas: dataPaketKelas })
    })
    .then(response => response.json())
    .then(hasil => {
        if (hasil.status === 'success') {
            semuaBaris.forEach(baris => {
                const cKode = baris.querySelector('.edit-kode');
                const cNama = baris.querySelector('.edit-nama');
                const cWali = baris.querySelector('.edit-wali');

                const vKode = cKode.querySelector('input').value.trim();
                const vNama = cNama.querySelector('input').value.trim();
                const vWali = cWali.querySelector('input').value.trim();

                cKode.innerHTML = vKode; cKode.setAttribute('data-asli', vKode);
                cNama.innerHTML = vNama; cNama.setAttribute('data-asli', vNama);
                cWali.innerHTML = vWali; cWali.setAttribute('data-asli', vWali);
            });

            document.getElementById('btnMode').style.display = 'inline-block';
            document.getElementById('btnBatal').style.display = 'none';
            document.getElementById('btnSimpan').style.display = 'none';
            alert('Sukses! Seluruh perubahan data kelas & wali kelas berhasil disimpan serentak.');
        } else {
            alert('Gagal menyimpan: ' + hasil.message);
        }
    }).catch(error => console.error('Error:', error));
}
