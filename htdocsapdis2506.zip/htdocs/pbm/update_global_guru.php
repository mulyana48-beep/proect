<?php
session_start();
include "config.php";

// Proteksi keamanan admin
if (!isset($_SESSION['username']) || $_SESSION['level_user'] !== 'admin') {
    die(json_encode(['status' => 'error', 'message' => 'Akses ditolak!']));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputData = json_decode(file_get_contents("php://input"), true);

    if (isset($inputData['data_guru']) && is_array($inputData['data_guru'])) {
        $sukses = true;
        
        foreach ($inputData['data_guru'] as $item) {
            $kode = mysqli_real_escape_string($con, $item['kode']);
            $mapel = mysqli_real_escape_string($con, $item['mapel']);
            $nama_guru = mysqli_real_escape_string($con, $item['nama_guru']);
            $tingkat = mysqli_real_escape_string($con, $item['tingkat']);
            $passed = mysqli_real_escape_string($con, $item['passed']);
            $tugas = mysqli_real_escape_string($con, $item['tugas']);
            $kosong = mysqli_real_escape_string($con, $item['kosong']);
            
            if (!empty($kode)) {
                $query_string = "UPDATE mapel_guru SET 
                                 `mapel` = '$mapel', 
                                 `nama_guru` = '$nama_guru', 
                                 `tingkat` = '$tingkat', 
                                 `passed` = '$passed', 
                                 `tugas` = '$tugas', 
                                 `kosong` = '$kosong' 
                                 WHERE `kode` = '$kode'";
                                 
                if (!mysqli_query($con, $query_string)) {
                    $sukses = false;
                }
            }
        }
        
        if ($sukses) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui beberapa data guru.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid.']);
    }
}
?>
