
<?php 
// 1. Ambil navigasi atas dan koneksi database
include 'header.php'; 

// Tambahkan ini di bagian paling atas index.php setelah session_start()
if (isset($_SESSION['username'])) {
    include "config.php";
    $user_cek = $_SESSION['username'];
    $query_cek = mysqli_query($con, "SELECT is_default FROM users WHERE username = '$user_cek'");
    $data_cek = mysqli_fetch_assoc($query_cek);
    
    if ($data_cek['is_default'] == 1) {
        header("Location: ganti_password_wajib.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        /* Style Ringan, Bersih, Modern, dan Sinkron dengan Form */
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; }
        
        body { 
            background-color: #f4f6f9; 
            color: #333; 
        }

        /* Pembungkus utama agar kotak rekap berada di tengah (Center) */
        .main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
            width: 100%;
        }

        /* Container Rekap Utama */
        .rekap-container { 
            background: #fff; 
            padding: 30px; 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.05); 
            width: 100%; 
            max-width: 800px; 
        }

        h2 { margin-bottom: 25px; text-align: center; color: #2c3e50; font-size: 24px; font-weight: 600; }
        
        /* Form Filter Kelas */
        .filter-section { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            display: flex; 
            gap: 15px; 
            align-items: flex-end; 
            justify-content: center; 
            border: 1px solid #eef2f5;
        }

        .form-group { display: flex; flex-direction: column; gap: 8px; }
        label { font-size: 14px; font-weight: 600; color: #555; }
        
        select { 
            padding: 12px 15px; 
            border: 1px solid #ddd; 
            border-radius: 8px; 
            font-size: 15px; 
            outline: none; 
            min-width: 280px; 
            cursor: pointer; 
            background-color: #fff;
            transition: border-color 0.3s;
        }
        select:focus { border-color: #4a90e2; }
        
        .btn-cari { 
            padding: 12px 24px; 
            background-color: #3498db; 
            border: none; 
            border-radius: 8px; 
            color: white; 
            font-size: 15px; 
            font-weight: bold; 
            cursor: pointer; 
            transition: background 0.2s; 
        }
        .btn-cari:hover { background-color: #2980b9; }

        /* Desain Tabel Rekap Modern */
        .table-responsive {
            width: 100%;
            overflow-x: auto; /* Mencegah tabel rusak/patah di HP */
            margin-top: 15px;
            border-radius: 8px;
            border: 1px solid #eef2f5;
        }

        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 14px 18px; text-align: left; border-bottom: 1px solid #eef2f5; }
        th { background-color: #2c3e50; color: white; font-weight: 600; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
        tr:last-child td { border-bottom: none; }
        tr:hover { background-color: #f8fafd; }
        
        /* Badge Indikator Angka */
        .badge { padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 13px; display: inline-block; text-align: center; min-width: 75px; }
        .badge-passed { background-color: #e8f5e9; color: #2e7d32; }
        .badge-tugas { background-color: #fff3e0; color: #ef6c00; }
        .badge-kosong { background-color: #ffebee; color: #c62828; }
        
        .nav-link { display: inline-block; margin-top: 25px; color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 14px; transition: color 0.2s; }
        .nav-link:hover { color: #27ae60; text-decoration: underline; }
        .info-kosong { text-align: center; color: #7f8c8d; padding: 35px; font-style: italic; font-size: 15px; }

        /* Optimasi Responsif Handphone */
        @media (max-width: 600px) {
            .filter-section { flex-direction: column; align-items: stretch; gap: 12px; }
            select { min-width: 100%; }
            .btn-cari { width: 100%; }
            th, td { padding: 10px 12px; font-size: 14px; }
            .badge { min-width: auto; padding: 4px 8px; font-size: 12px; }
        }
    </style>
</head>
<body>

<div class="main-content">

</body>
</html>
