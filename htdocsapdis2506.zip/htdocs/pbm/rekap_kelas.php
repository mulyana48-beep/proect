<?php 
include 'header.php'; 
include 'config.php'; 

$kelas_terpilih = isset($_POST['kelas']) ? mysqli_real_escape_string($con, $_POST['kelas']) : '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekapitulasi KBM Per Kelas</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; }
        body { 
            background-color: #f4f6f9; 
            color: #333; 
        }
        .main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px 20px;
            width: 100%;
        }
        .rekap-container { 
            background: #fff; 
            padding: 20px; 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.05); 
            width: 100%; 
            max-width: 720px; 
        }
        h2 { margin-bottom: 25px; text-align: center; color: #2c3e50; font-size: 24px; font-weight: 600; }
        .filter-section { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 8px; 
            margin-bottom: 25px; 
            display: flex; 
            gap: 15px; 
            align-items: flex-end; 
            justify-content: center; 
            border: 1px solid #eef2f5;
        }

        .form-group { display: flex; flex-direction: column; gap: 8px; }
        label { font-size: 14px; font-weight: 600; color: #555; }
        
        select { 
            padding: 12px 15px; 
            border: 1px solid #ddd; 
            border-radius: 8px; 
            font-size: 15px; 
            outline: none; 
            min-width: 280px; 
            cursor: pointer; 
            background-color: #fff;
            transition: border-color 0.3s;
        }
        select:focus { border-color: #4a90e2; }
        
        .btn-cari { 
            padding: 12px 24px; 
            background-color: #3498db; 
            border: none; 
            border-radius: 8px; 
            color: white; 
            font-size: 15px; 
            font-weight: bold; 
            cursor: pointer; 
            transition: background 0.2s; 
        }
        .btn-cari:hover { background-color: #2980b9; }

        /* Desain Tabel Rekap Modern */
        .table-responsive {
            width: 100%;
            overflow-x: auto; /* Mencegah tabel rusak/patah di HP */
            margin-top: 15px;
            border-radius: 8px;
            border: 1px solid #eef2f5;
        }

        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 14px 18px; text-align: left; border-bottom: 1px solid #eef2f5; }
        th { background-color: #2c3e50; color: white; font-weight: 600; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
        tr:last-child td { border-bottom: none; }
        tr:hover { background-color: #f8fafd; }
        
        /* Badge Indikator Angka */
        .badge { padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 13px; display: inline-block; text-align: center; min-width: 75px; }
        .badge-passed { background-color: #e8f5e9; color: #2e7d32; }
        .badge-tugas { background-color: #fff3e0; color: #ef6c00; }
        .badge-kosong { background-color: #ffebee; color: #c62828; }
        
        .nav-link { display: inline-block; margin-top: 25px; color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 14px; transition: color 0.2s; }
        .nav-link:hover { color: #27ae60; text-decoration: underline; }
        .info-kosong { text-align: center; color: #7f8c8d; padding: 35px; font-style: italic; font-size: 15px; }

        /* Optimasi Responsif Handphone */
        @media (max-width: 600px) {
            .filter-section { flex-direction: column; align-items: stretch; gap: 12px; }
            select { min-width: 100%; }
            .btn-cari { width: 100%; }
            th, td { padding: 10px 12px; font-size: 14px; }
            .badge { min-width: auto; padding: 4px 8px; font-size: 12px; }
        }
    </style>
</head>
<body>

<div class="main-content">
    <div class="rekap-container">
        <h2>Rekapitulasi KBM Berdasarkan Kelas</h2>
        
        <form action="" method="POST" class="filter-section">
            <div class="form-group">
                <label for="kelas">Pilih Kelas :</label>
                <select name="kelas" id="kelas" required>
                    <option value="">-- Silakan Pilih Kelas --</option>
                    <?php
                    // Ambil daftar kelas dari tabel master_kelas Anda
                    $query_master_kelas = "SELECT kode_kelas, nama_kelas FROM master_kelas ORDER BY kode_kelas ASC";
                    $eksekusi_master = mysqli_query($con, $query_master_kelas);
                    
                    while ($row_kelas = mysqli_fetch_assoc($eksekusi_master)) {
                        $selected = ($kelas_terpilih == $row_kelas['kode_kelas']) ? 'selected' : '';
                        echo "<option value='{$row_kelas['kode_kelas']}' $selected>{$row_kelas['nama_kelas']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn-cari">Tampilkan Data</button>
        </form>

        <!-- Bagian Menampilkan Tabel Data -->
        <?php if (!empty($kelas_terpilih)): ?>
            <?php
            // QUERY JOIN untuk mengambil nama mapel asli
            $query_rekap = "SELECT rkm.kode_mapel, mg.mapel AS nama_mapel_asli, rkm.passed, rkm.tugas, rkm.kosong 
                            FROM rekap_kelas_mapel rkm
                            INNER JOIN mapel_guru mg ON rkm.kode_mapel = mg.kode
                            WHERE rkm.kode_kolom_kelas = '$kelas_terpilih' 
                            ORDER BY mg.kode ASC";

            $eksekusi_rekap = mysqli_query($con, $query_rekap);
            
            if ($eksekusi_rekap && mysqli_num_rows($eksekusi_rekap) > 0): 
            ?>
                <!-- Pembungkus responsif agar tabel tidak terpotong di layar kecil -->
                <div class="table-responsive">
                    <table>
<thead>
    <tr>
        <th style="width: 8%; text-align: center;">No</th> <!-- Kolom nomor baru -->
        <th style="width: 45%;">Mata Pelajaran</th>
        <th style="text-align: center; width: 15%;">Passed (P)</th>
        <th style="text-align: center; width: 15%;">Tugas (T)</th>
        <th style="text-align: center; width: 17%;">Kosong (K)</th>
    </tr>
</thead>

<tbody>
    <?php 
    $no = 1; // 1. Inisialisasi nomor awal sebelum looping dimulai
    while ($data = mysqli_fetch_assoc($eksekusi_rekap)): 
    ?>
        <tr>
            <!-- 2. Cetak nomor urut otomatis ke bawah -->
            <td style="text-align: center; color: #7f8c8d; font-weight: 500;">
                <?php echo $no++; ?>
            </td>

            <td style="font-weight: 600; color: #34495e;">
                <?php echo htmlspecialchars($data['nama_mapel_asli']); ?> 
                <span style="font-weight: normal; color: #95a5a6; font-size: 13px;">(<?php echo htmlspecialchars($data['kode_mapel']); ?>)</span>
            </td>
            <td style="text-align: center;"><span class="badge badge-passed"><?php echo $data['passed']; ?> JP</span></td>
            <td style="text-align: center;"><span class="badge badge-tugas"><?php echo $data['tugas']; ?> JP</span></td>
            <td style="text-align: center;"><span class="badge badge-kosong"><?php echo $data['kosong']; ?> JP</span></td>
        </tr>
    <?php endwhile; ?>
</tbody>

                    </table>
                </div>
            <?php else: ?>
                <p class="info-kosong">Belum ada riwayat data pencatatan KBM untuk kelas ini.</p>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
