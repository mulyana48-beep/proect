<?php
session_start();
include "config.php";

// Proteksi keamanan admin
if (!isset($_SESSION['username']) || $_SESSION['level_user'] !== 'admin') {
    die(json_encode(['status' => 'error', 'message' => 'Akses ditolak!']));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputData = json_decode(file_get_contents("php://input"), true);

    if (isset($inputData['data_jadwal']) && is_array($inputData['data_jadwal'])) {
        $sukses = true;
        
        foreach ($inputData['data_jadwal'] as $item) {
            $id_jadwal = mysqli_real_escape_string($con, $item['id_jadwal']);
            
            // Susun query UPDATE secara dinamis berdasarkan kolom kelas yang dikirim
            $update_parts = [];
            foreach ($item['kelas'] as $kolom_kelas => $nilai_mapel) {
                $kolom_clean = mysqli_real_escape_string($con, $kolom_kelas);
                $nilai_clean = mysqli_real_escape_string($con, $nilai_mapel);
                $update_parts[] = "`$kolom_clean` = '$nilai_clean'";
            }
            
            if (!empty($update_parts)) {
                $query_string = "UPDATE jadwal SET " . implode(", ", $update_parts) . " WHERE id_jadwal = '$id_jadwal'";
                if (!mysqli_query($con, $query_string)) {
                    $sukses = false;
                }
            }
        }
        
        if ($sukses) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui beberapa jadwal.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid.']);
    }
}
?>
