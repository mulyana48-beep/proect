<?php 
include 'header.php'; 
include 'config.php'; 

if ($_SESSION['level_user'] !== 'admin') {
    echo "<script>alert('Akses Khusus Admin!'); window.location.href='form.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Jadwal KBM Global</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
        body { background-color: #f4f6f9; color: #333; }
        
        /* Modifikasi area agar melebar penuh kiri-kanan layar */
        .main-content { padding: 10px; width: 100%; }
        .rekap-container { background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; max-width: 100%; }
        
        .action-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 15px; }
        h2 { color: #2c3e50; font-size: 22px; font-weight: 600; }
        
        .btn { padding: 10px 20px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 14px; transition: 0.2s; }
        .btn-mode-edit { background-color: #3498db; color: white; }
        .btn-mode-edit:hover { background-color: #2980b9; }
        .btn-simpan-semua { background-color: #2ecc71; color: white; display: none; }
        .btn-simpan-semua:hover { background-color: #27ae60; }
        .btn-batal { background-color: #95a5a6; color: white; display: none; margin-right: 10px; }
        .btn-batal:hover { background-color: #7f8c8d; }

        /* Pembungkus scroll horizontal karena kolom berjumlah 38 buah */
        .table-responsive { width: 100%; overflow-x: auto; border: 1px solid #eef2f5; border-radius: 8px; margin-top: 10px; }
        table { width: 100%; border-collapse: collapse; background: #fff; min-width: 2500px; } /* Memaksa tabel memanjang ke samping agar muat 36 kelas */
/* 1. Atur padding sel tabel asli agar sangat tipis */
th, td { 
    padding: 1px 4px !important; /* Memaksa padding atas-bawah hanya 1px */
    text-align: center; 
    border-bottom: 1px solid #eef2f5; 
    font-size: 13px; 
    border-right: 1px solid #f1f1f1; 
}

/* 2. Atur kotak input mode edit agar pas presisi & tidak mendesak sel */
.input-inline { 
    width: 100%; 
    padding: 1px 2px !important; /* Menyetel padding dalam kotak input menjadi 1px */
    margin: 0 !important;        /* Menghilangkan margin bawaan browser */
    height: 24px;                /* Mengunci tinggi kotak agar tidak merusak tinggi baris tabel */
    line-height: 22px; 
    border: 1px solid #ddd; 
    border-radius: 4px; 
    font-size: 12px;             /* Sedikit diperkecil agar teks mapel muat di kotak tipis */
    outline: none; 
    text-align: center; 
    box-sizing: border-box;      /* Memaksa padding dihitung di dalam ukuran kotak */
}

/* Efek fokus saat kotak input sedang aktif diketik */
.input-inline:focus { 
    border-color: #3498db; 
    background-color: #fff; 
}

        /* Mengubah kursor menjadi bentuk tangan siap menyeret data */
.table-responsive {
    cursor: grab;
    user-select: none; /* Mencegah teks terblok secara tidak sengaja saat diseret */
}

/* Ketika tabel sedang dalam kondisi diklik dan diseret */
.table-responsive:active {
    cursor: grabbing;
}
/* Kontainer utama penggeser mengambang */
.floating-scrollbar-container {
    position: sticky;
    bottom: 0; /* Mengunci posisi tepat di batas bawah layar browser */
    width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    background: rgba(255, 255, 255, 0.9); /* Sedikit transparan agar elegan */
    box-shadow: 0 -4px 10px rgba(0,0,0,0.05);
    z-index: 99;
    height: 16px; /* Tinggi batang penggeser */
    border-radius: 0 0 12px 12px;
}

/* Konten tiruan di dalam penggeser agar panjangnya sama dengan lebar tabel asli */
.floating-scrollbar-content {
    height: 1px;
    width: 2500px; /* Harus SAMA PERSIS dengan min-width tabel asli Anda */
}

/* Mempercantik tampilan batang penggeser agar terlihat modern */
.floating-scrollbar-container::-webkit-scrollbar {
    height: 10px;
}
.floating-scrollbar-container::-webkit-scrollbar-track {
    background: #f1f1f1;
}
.floating-scrollbar-container::-webkit-scrollbar-thumb {
    background: #3498db;
    border-radius: 10px;
}
.floating-scrollbar-container::-webkit-scrollbar-thumb:hover {
    background: #2980b9;
}

    </style>
</head>
<body>

<div class="main-content">
    <div class="rekap-container">
        <div class="action-bar">
            <h2>Master Jadwal Pelajaran (36 Kelas)</h2>
            <div>
                <button type="button" id="btnBatal" class="btn btn-batal" onclick="batalEditJadwal()">Batal</button>
                <button type="button" id="btnMode" class="btn btn-mode-edit" onclick="aktifkanModeEditJadwal()">Masuk Mode Edit</button>
                <button type="button" id="btnSimpan" class="btn btn-simpan-semua" onclick="simpanPerubahanJadwal()">Simpan Semua Perubahan</button>
            </div>
        </div>
<!-- Batang Penggeser Mengambang di Bawah Layar -->
<div class="floating-scrollbar-container" id="floatingScrollbarContainer">
    <div class="floating-scrollbar-content"></div>
</div>

<!-- Tabel Responsive Anda yang asli ada di bawah sini -->
<div class="table-responsive">
    <table id="tabelJadwal">
    ...
        
        <div class="table-responsive">
            <table id="tabelJadwal">
                <thead>
                    <tr>
                        <th style="width: 100px; text-align: left;">Hari Jam</th>
                        <?php 
                        // Loop otomatis untuk mencetak judul kolom kelas_01 sampai kelas_36
                        for ($k = 1; $k <= 36; $k++) {
                            echo "<th>Kls-" . sprintf("%02d", $k) . "</th>";
                        }
                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM jadwal ORDER BY id_jadwal ASC";
                    $eksekusi = mysqli_query($con, $query);
                    while ($row = mysqli_fetch_assoc($eksekusi)):
                    ?>
                    <tr class="baris-jadwal" data-id="<?php echo $row['id_jadwal']; ?>">
                        <!-- Kolom kriteria hari_jam -->
                        <td class="hari-jam-text"><?php echo htmlspecialchars($row['hari_jam']); ?></td>
                        
                        <!-- Loop data nilai mapel untuk ke-36 kolom kelas -->
                        <?php for ($k = 1; $k <= 36; $k++): 
                            $nama_kolom = "kelas_" . sprintf("%02d", $k);
                            $nilai_mapel = $row[$nama_kolom];
                        ?>
                            <td class="kolom-mapel" data-kolom="<?php echo $nama_kolom; ?>" data-asli="<?php echo htmlspecialchars($nilai_mapel); ?>">
                                <?php echo htmlspecialchars($nilai_mapel); ?>
                            </td>
                        <?php endfor; ?>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// 1. Mengubah seluruh sel mapel menjadi input teks secara serentak
function aktifkanModeEditJadwal() {
    const semuaBaris = document.querySelectorAll('.baris-jadwal');
    
    semuaBaris.forEach(baris => {
        const semuaKolomMapel = baris.querySelectorAll('.kolom-mapel');
        semuaKolomMapel.forEach(td => {
            const teksSekarang = td.innerText.trim();
            td.innerHTML = `<input type="text" class="input-inline" value="${teksSekarang}">`;
        });
    });

    document.getElementById('btnMode').style.display = 'none';
    document.getElementById('btnBatal').style.display = 'inline-block';
    document.getElementById('btnSimpan').style.display = 'inline-block';
}

// 2. Membatalkan editan dan mengembalikan semua teks jadwal semula
function batalEditJadwal() {
    const semuaBaris = document.querySelectorAll('.baris-jadwal');
    
    semuaBaris.forEach(baris => {
        const semuaKolomMapel = baris.querySelectorAll('.kolom-mapel');
        semuaKolomMapel.forEach(td => {
            td.innerHTML = td.getAttribute('data-asli');
        });
    });

    document.getElementById('btnMode').style.display = 'inline-block';
    document.getElementById('btnBatal').style.display = 'none';
    document.getElementById('btnSimpan').style.display = 'none';
}

// 3. Mengumpulkan seluruh matriks tabel input dan mengirim paket data via JSON
function simpanPerubahanJadwal() {
    const semuaBaris = document.querySelectorAll('.baris-jadwal');
    let dataPaketJadwal = [];

    semuaBaris.forEach(baris => {
        const idJadwal = baris.getAttribute('data-id');
        const semuaKolomMapel = baris.querySelectorAll('.kolom-mapel');
        
        let subDataKelas = {};
        semuaKolomMapel.forEach(td => {
            const namaKolom = td.getAttribute('data-kolom');
            const nilaiInput = td.querySelector('.input-inline').value.trim();
            subDataKelas[namaKolom] = nilaiInput;
        });

        dataPaketJadwal.push({
            id_jadwal: idJadwal,
            kelas: subDataKelas
        });
    });

    // Kirim data matriks raksasa ini ke server PHP
    fetch('update_global_jadwal.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_jadwal: dataPaketJadwal })
    })
    .then(response => response.json())
    .then(hasil => {
        if (hasil.status === 'success') {
            // Kunci kembali semua input menjadi teks biasa
            semuaBaris.forEach(baris => {
                const semuaKolomMapel = baris.querySelectorAll('.kolom-mapel');
                semuaKolomMapel.forEach(td => {
                    const nilaiBaru = td.querySelector('.input-inline').value.trim();
                    td.innerHTML = nilaiBaru;
                    td.setAttribute('data-asli', nilaiBaru); // Perbarui cadangan teks asli
                });
            });

            document.getElementById('btnMode').style.display = 'inline-block';
            document.getElementById('btnBatal').style.display = 'none';
            document.getElementById('btnSimpan').style.display = 'none';
            
            alert('Hebat! Seluruh matriks jadwal 36 kelas berhasil disimpan serentak!');
        } else {
            alert('Gagal menyimpan perubahan: ' + hasil.message);
        }
    })
    .catch(error => console.error('Error:', error));
}
    // =========================================================================
// FITUR NAVIGASI SERET TABEL KIRI-KANAN (DRAG-TO-SCROLL)
// =========================================================================
const slider = document.querySelector('.table-responsive');
let isDown = false;
let startX;
let scrollLeft;

slider.addEventListener('mousedown', (e) => {
    // Fitur seret hanya aktif jika pengguna TIDAK sedang mengklik kotak input text
    if (e.target.tagName === 'INPUT') return;

    isDown = true;
    slider.classList.add('active');
    startX = e.pageX - slider.offsetLeft;
    scrollLeft = slider.scrollLeft;
});

slider.addEventListener('mouseleave', () => {
    isDown = false;
});

slider.addEventListener('mouseup', () => {
    isDown = false;
});

slider.addEventListener('mousemove', (e) => {
    if(!isDown) return;
    e.preventDefault(); // Mencegah efek bawaan browser yang mengganggu
    const x = e.pageX - slider.offsetLeft;
    const walk = (x - startX) * 2; // Angka 2 adalah kecepatan seret, bisa dinaikkan jika kurang cepat
    slider.scrollLeft = scrollLeft - walk;
});
// =========================================================================
// =========================================================================
// FITUR PENGGESER MENGAMBANG DI BAWAH LAYAR (FLOATING TWIN SCROLL)
// =========================================================================
const tabelAsli = document.querySelector('.table-responsive');
const penggeserApung = document.getElementById('floatingScrollbarContainer');

// Jika penggeser apung digeser, tabel asli ikut bergeser
penggeserApung.addEventListener('scroll', () => {
    tabelAsli.scrollLeft = penggeserApung.scrollLeft;
});

// Jika tabel asli digeser (atau diseret pakai mouse), penggeser apung ikut bergerak
tabelAsli.addEventListener('scroll', () => {
    penggeserApung.scrollLeft = tabelAsli.scrollLeft;
});
// =========================================================================

</script>

</body>
</html>
