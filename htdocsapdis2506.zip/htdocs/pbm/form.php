<?php
include "header.php"; 
include "config.php"; 

$nama_user_sekarang = isset($_SESSION['nama_user']) ? $_SESSION['nama_user'] : '';
$kode_kelas_otomatis = ""; 

if (!empty($nama_user_sekarang) && $con) {
    $nama_user_safe = mysqli_real_escape_string($con, $nama_user_sekarang);
    $query_kelas = "SELECT kode_kelas FROM master_kelas WHERE nama_kelas = '$nama_user_safe'";
    $result_kelas = mysqli_query($con, $query_kelas);
    if ($result_kelas && mysqli_num_rows($result_kelas) > 0) {
        $row_kelas = mysqli_fetch_assoc($result_kelas);
        $kode_kelas_otomatis = $row_kelas['kode_kelas'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Catat KBM</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
        body { background-color: #f4f6f9; color: #333; }
        .main-content { display: flex; justify-content: center; align-items: center; padding: 5px 10px; width: 100%; }
        .form-container { background: #ffffff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; max-width: 720px; }
        h2 { margin-bottom: 25px; text-align: center; color: #2c3e50; font-size: 24px; font-weight: 600; }
        .row-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; color: #555; }
        input[type="date"], input[type="text"] { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 15px; outline: none; background-color: #fdfdfd; }
        input[readonly] { background-color: #f1f3f5; color: #777; cursor: not-allowed; border-color: #e2e8f0; }
        .jam-section { border-top: 1px solid #eef2f5; padding-top: 20px; margin-top: 20px; }
        .jam-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #f8f9fa; }
        .jam-label { font-weight: 600; color: #34495e; font-size: 15px; }
/* Desain Pita Kotak Menyatu - Diperbarui agar warna penuh */
.pita-container { 
    display: flex; 
    border: 1px solid #ddd; 
    border-radius: 8px; 
    overflow: hidden; 
    height: 38px;
    align-items: stretch; /* Memaksa semua label di dalamnya memiliki tinggi penuh yang sama */
}

.pita-container input[type="radio"] { 
    display: none; 
}

.pita-label { 
    display: flex; 
    align-items: center; /* Menengahkan teks secara vertikal */
    justify-content: center; /* Menengahkan teks secara horizontal */
    padding: 0 15px; 
    height: 100%; /* Memaksa tinggi label memenuhi 100% kontainer pita */
    background-color: #fff; 
    color: #666; 
    font-weight: 600; 
    font-size: 13px; 
    cursor: pointer; 
    text-align: center; 
    min-width: 55px; 
    border-right: 1px solid #ddd; 
    transition: all 0.2s ease; 
    user-select: none; 
    flex: 1; /* Membuat setiap kotak membagi ruang dengan adil dan rapat */
}

.pita-label:last-of-type { 
    border-right: none; 
}

        input[id$="-P"]:checked + .pita-label { background-color: #4a90e2; color: #fff; border-color: #4a90e2; }
        input[id$="-T"]:checked + .pita-label { background-color: #f39c12; color: #fff; border-color: #f39c12; }
        input[id$="-K"]:checked + .pita-label { background-color: #e74c3c; color: #fff; border-color: #e74c3c; }
        .btn-submit { width: 100%; padding: 14px; background-color: #2ecc71; border: none; border-radius: 8px; color: white; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 25px; box-shadow: 0 4px 12px rgba(46, 204, 113, 0.2); }
        @media (max-width: 576px) { .row-meta { grid-template-columns: 1fr; gap: 10px; } .jam-row { flex-direction: column; align-items: flex-start; gap: 10px; padding: 15px 0; } .pita-container { width: 100%; } .pita-label { flex: 1; } }
    </style>
</head>
<body>

<div class="main-content">
    <div class="form-container">
        <h2>Catatan Harian KBM</h2>

        <form action="simpan.php" method="POST">
            <div class="row-meta">
                <div class="form-group">
                    <label for="tanggal">Tanggal</label>
                    <!-- Ditambahkan event onchange untuk mendeteksi perubahan tanggal -->
                    <input type="date" id="tanggal" name="tanggal" required value="<?php echo date('d-m-Y'); ?>" onchange="muatMapelOtomatis()">
                </div>
                <div class="form-group">
                    <label for="tampilan_kelas">Kelas</label>
                    <input type="text" id="tampilan_kelas" value="<?php echo htmlspecialchars($nama_user_sekarang); ?>" readonly>
                    <input type="hidden" id="kelas" name="kelas" value="<?php echo htmlspecialchars($kode_kelas_otomatis); ?>">
                </div>
            </div>

            <div class="jam-section">
                <label style="margin-bottom: 12px; color: #7f8c8d; display:block; font-size:13px; font-weight: 500;">Status Pembelajaran Harian:</label>
                
                <?php for ($i = 1; $i <= 10; $i++): $num = sprintf("%02d", $i); ?>
                    <div class="jam-row">
                        <div class="jam-info" style="display: flex; flex-direction: column; gap: 2px;">
                            <span class="jam-label">Jam Ke-<?php echo $num; ?></span>
                            <!-- Bagian teks mapel yang akan diisi otomatis oleh JavaScript -->
                            <span class="mapel-label" id="text-mapel-<?php echo $num; ?>" style="font-size: 13px; color: #7f8c8d; font-weight: 500;">
                                📚 Memuat...
                            </span>
                        </div>
                        
<div class="pita-container">
    <!-- Tambahkan onclick="toggleRadio(this)" pada setiap input -->
    <input type="radio" id="sjam_<?php echo $num; ?>-P" name="sjam_ke_<?php echo $num; ?>" value="P" onclick="toggleRadio(this)">
    <label for="sjam_<?php echo $num; ?>-P" class="pita-label">Tatap Muka</label>

    <input type="radio" id="sjam_<?php echo $num; ?>-T" name="sjam_ke_<?php echo $num; ?>" value="T" onclick="toggleRadio(this)">
    <label for="sjam_<?php echo $num; ?>-T" class="pita-label">Tugas</label>

    <input type="radio" id="sjam_<?php echo $num; ?>-K" name="sjam_ke_<?php echo $num; ?>" value="K" onclick="toggleRadio(this)">
    <label for="sjam_<?php echo $num; ?>-K" class="pita-label">Kosong</label>
</div>

                    </div>
                <?php endfor; ?>
            </div>

<button type="submit" class="btn-submit" onclick="return konfirmasiSimpan()">Simpan Data KBM</button>
        </form>
    </div>
</div>

<!-- JAVASCRIPT UNTUK OTOMATISASI MAPEL SECARA REAL-TIME -->
<script>
function muatMapelOtomatis() {
    const tanggal = document.getElementById('tanggal').value;
    const kelas = document.getElementById('kelas').value;

    if (!tanggal || !kelas) return;

    // Mengambil data dari file ambil_mapel.php tanpa reload halaman
    fetch(`ambil_mapel.php?tanggal=${tanggal}&kelas=${kelas}`)
        .then(response => response.json())
        .then(data => {
            // Pasang nama mapel ke masing-masing jam row secara tepat
            for (let i = 1; i <= 10; i++) {
                const num = String(i).padStart(2, '0');
                const elemenMapel = document.getElementById(`text-mapel-${num}`);
                if (elemenMapel && data[num]) {
                    elemenMapel.innerHTML = '📚 ' + data[num];
                }
            }
        })
        .catch(error => {
            console.error('Error memuat data mapel:', error);
        });
}

// Jalankan fungsi pertama kali saat halaman form baru dibuka
document.addEventListener("DOMContentLoaded", function() {
    muatMapelOtomatis();
});
    
    // Variabel global untuk menyimpan status tombol terakhir yang diklik
let lastCheckedRadio = null;

function toggleRadio(radio) {
    // Jika tombol yang diklik sama dengan tombol yang sebelumnya aktif
    if (lastCheckedRadio === radio) {
        radio.checked = false;      // Batalkan pilihan (uncheck)
        lastCheckedRadio = null;    // Kosongkan status memori
    } else {
        lastCheckedRadio = radio;    // Simpan tombol ini sebagai yang aktif
    }
}

// Tambahan agar fungsi bekerja mendeteksi perubahan fokus antar baris jam
document.querySelectorAll('.pita-container input[type="radio"]').forEach(radio => {
    radio.addEventListener('mousedown', function() {
        if (this.checked) {
            this.dataset.wasChecked = 'true';
        } else {
            this.dataset.wasChecked = 'false';
        }
    });

    radio.addEventListener('click', function() {
        if (this.dataset.wasChecked === 'true') {
            this.checked = false;
            this.dataset.wasChecked = 'false';
        }
    });
});
function konfirmasiSimpan() {
    return confirm("Pastikan Tanggal dan Status KBM sudah benar!");
}
</script>

</body>
</html>
