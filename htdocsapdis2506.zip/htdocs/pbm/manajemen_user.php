<?php
session_start();
require_once 'config.php';

// 1. Hak Akses: Hanya level_user 'Admin' yang boleh membuka halaman ini
if (!isset($_SESSION['username']) || $_SESSION['level_user'] !== 'admin') {
    echo "<script>alert('Akses ditolak! Halaman ini hanya untuk Admin.'); window.location='index.php';</script>";
    exit;
}

// 2. Proses: Tambah User Baru
if (isset($_POST['tambah_user'])) {
    $nama_user  = mysqli_real_escape_string($con, $_POST['nama_user']);
    $username   = mysqli_real_escape_string($con, $_POST['username']);
    $level_user = mysqli_real_escape_string($con, $_POST['level_user']);
    
    $password_default = password_hash('rahasia123', PASSWORD_DEFAULT);
    $is_default       = 1; 

    $cek_username = mysqli_query($con, "SELECT id FROM users WHERE username = '$username'");
    if (mysqli_num_rows($cek_username) > 0) {
        echo "<script>alert('Username sudah digunakan!'); window.location='manajemen_user.php';</script>";
        exit;
    }

    $query = "INSERT INTO users (nama_user, username, password, level_user, is_default) 
              VALUES ('$nama_user', '$username', '$password_default', '$level_user', '$is_default')";
              
    if (mysqli_query($con, $query)) {
        echo "<script>alert('User berhasil ditambahkan!'); window.location='manajemen_user.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah user: " . mysqli_error($con) . "');</script>";
    }
}

// 3. Proses: Reset Akun ke Default
if (isset($_GET['action']) && $_GET['action'] == 'reset' && isset($_GET['id'])) {
    $id_user = mysqli_real_escape_string($con, $_GET['id']);
    $password_reset = password_hash('rahasia123', PASSWORD_DEFAULT);
    $is_default     = 1;

    $query_reset = "UPDATE users SET password = '$password_reset', is_default = '$is_default' WHERE id = '$id_user'";
    
    if (mysqli_query($con, $query_reset)) {
        echo "<script>alert('Akun berhasil direset!'); window.location='manajemen_user.php';</script>";
    } else {
        echo "<script>alert('Gagal mereset akun: " . mysqli_error($con) . "');</script>";
    }
}

// 4. Proses: Hapus User
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_user = mysqli_real_escape_string($con, $_GET['id']);
    $cek_diri = mysqli_query($con, "SELECT username FROM users WHERE id = '$id_user'");
    $data_hapus = mysqli_fetch_assoc($cek_diri);
    
    if ($data_hapus['username'] === $_SESSION['username']) {
        echo "<script>alert('Gagal! Anda tidak bisa menghapus akun sendiri.'); window.location='manajemen_user.php';</script>";
        exit;
    }

    $query_delete = "DELETE FROM users WHERE id = '$id_user'";
    if (mysqli_query($con, $query_delete)) {
        echo "<script>alert('User berhasil dihapus!'); window.location='manajemen_user.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus user: " . mysqli_error($con) . "');</script>";
    }
}

include 'header.php';
?>

<style>
    .mu-container { max-width: 1100px; margin: 30px auto; padding: 0 20px; font-family: sans-serif; color: #333; }
    .mu-title { font-size: 26px; font-weight: 600; margin-bottom: 5px; color: #2c3e50; }
    .mu-subtitle { font-size: 14px; color: #7f8c8d; margin-bottom: 25px; }
    .mu-card { background: #fff; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); padding: 25px; margin-bottom: 30px; border: 1px solid #eef2f5; }
    .mu-card h3 { font-size: 18px; margin-bottom: 20px; color: #34495e; border-bottom: 2px solid #f1f3f5; padding-bottom: 10px; }
    .mu-form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; align-items: flex-end; }
    .mu-form-group { display: flex; flex-direction: column; }
    .mu-form-group label { font-size: 13px; font-weight: 600; margin-bottom: 8px; color: #555; }
    .mu-input { width: 100%; padding: 10px 14px; border: 1px solid #dcdde1; border-radius: 6px; font-size: 14px; outline: none; box-sizing: border-box; }
    .mu-input:focus { border-color: #4a90e2; }
    .mu-btn-submit { padding: 11px 20px; background-color: #2ecc71; color: white; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; }
    .mu-table-responsive { width: 100%; overflow-x: auto; background: #fff; border-radius: 10px; border: 1px solid #eef2f5; }
    .mu-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
    .mu-table th { background-color: #f8f9fa; color: #2c3e50; padding: 15px; font-weight: 600; border-bottom: 2px solid #eef2f5; }
    .mu-table td { padding: 15px; border-bottom: 1px solid #f1f3f5; color: #4a5568; }
    .mu-badge { padding: 4px 10px; border-radius: 50px; font-size: 12px; font-weight: 600; display: inline-block; }
    .mu-badge-danger { background-color: #fce8e6; color: #c53030; }
    .mu-badge-success { background-color: #e6fffa; color: #00875a; }
    .mu-badge-level { background-color: #edf2f7; color: #4a5568; }
    .mu-btn-action { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; text-decoration: none; display: inline-block; }
    .mu-btn-reset { background-color: #fef3c7; color: #d97706; margin-right: 5px; }
    .mu-btn-delete { background-color: #fee2e2; color: #dc2626; }
</style>
<div class="mu-container">
    <div class="mu-title">Manajemen Akun User</div>
    <div class="mu-subtitle">Kelola hak akses pendaftaran, hapus pengguna, dan atur ulang kata sandi aplikasi KBM.</div>

    <!-- BOX FORM TAMBAH USER -->
    <div class="mu-card">
        <h3>Tambah Pengguna Baru</h3>
        <form action="" method="POST" onsubmit="return konfirmasiTambah()">
            <div class="mu-form-grid">
                <div class="mu-form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama_user" class="mu-input" placeholder="Contoh: Ahmad Subarjo" required autocomplete="off">
                </div>
                <div class="mu-form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="mu-input" placeholder="Contoh: ahmad_kbm" required autocomplete="off">
                </div>
                <div class="mu-form-group">
                    <label>Level Akses</label>
                    <select name="level_user" class="mu-input" required>
                        <option value="">-- Pilih Level --</option>
                        <option value="admin">Admin</option>
                        <option value="user_kelas">User Kelas</option>
                    </select>
                </div>
                <div>
                    <button type="submit" name="tambah_user" class="mu-btn-submit">
                        + Tambah User
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- TABEL DAFTAR USER -->
    <div class="mu-card" style="padding: 10px 0 0 0;">
        <h3 style="padding: 15px 25px 10px 25px; margin-bottom: 0;">Daftar Pengguna Aktif</h3>
        <div class="mu-table-responsive">
            <table class="mu-table">
                <thead>
                    <tr>
                        <th style="width: 60px; text-align: center;">No</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Level</th>
                        <th>Keamanan Password</th>
                        <th style="width: 180px; text-align: center;">Aksi Kontrol</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $tampil = mysqli_query($con, "SELECT * FROM users ORDER BY id ASC");
                    if (mysqli_num_rows($tampil) == 0) {
                        echo "<tr><td colspan='6' style='text-align:center; padding: 30px;'>Belum ada data user.</td></tr>";
                    }
                    while ($data = mysqli_fetch_array($tampil)) {
                        $status_pwd = ($data['is_default'] == 1) 
                            ? "<span class='mu-badge mu-badge-danger'>Bawaan (Wajib Ganti)</span>" 
                            : "<span class='mu-badge mu-badge-success'>Sudah Diubah</span>";
                    ?>
                        <tr>
                            <td style="text-align: center; color: #94a3b8;"><?= $no++; ?></td>
                            <td style="font-weight: 500; color: #1e293b;"><?= htmlspecialchars($data['nama_user']); ?></td>
                            <td style="font-family: monospace; color: #64748b;"><?= htmlspecialchars($data['username']); ?></td>
                            <td><span class="mu-badge mu-badge-level"><?= htmlspecialchars($data['level_user']); ?></span></td>
                            <td><?= $status_pwd; ?></td>
                            <td style="text-align: center;">
                                <a href="manajemen_user.php?action=reset&id=<?= $data['id']; ?>" class="mu-btn-action mu-btn-reset" onclick="return konfirmasiReset('<?= htmlspecialchars($data['nama_user']); ?>')">Reset</a>
                                <a href="manajemen_user.php?action=delete&id=<?= $data['id']; ?>" class="mu-btn-action mu-btn-delete" onclick="return konfirmasiHapus('<?= htmlspecialchars($data['nama_user']); ?>')">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function konfirmasiTambah() { return confirm("Apakah data user baru sudah benar? Password otomatis di-set ke 'rahasia123'."); }
define(function(){}); // bypass token safe
function konfirmasiReset(nama) { return confirm("Apakah Anda yakin ingin mereset akun " + nama + "? Password akan kembali menjadi 'rahasia123'."); }
function konfirmasiHapus(nama) { return confirm("PERINGATAN PERMANEN!\n\nApakah Anda yakin ingin menghapus akun " + nama + "?"); }
</script>
