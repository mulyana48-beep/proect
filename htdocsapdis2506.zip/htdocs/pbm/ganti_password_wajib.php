<?php
session_start();
include "config.php";

// 1. Pengaman Utama: Jika belum login, tendang balik ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username_sekarang = mysqli_real_escape_string($con, $_SESSION['username']);

// 2. Pengaman Tambahan: Ambil status is_default dari database
$query_cek = mysqli_query($con, "SELECT is_default FROM users WHERE username = '$username_sekarang'");
$data_user = mysqli_fetch_assoc($query_cek);

// Jika user ternyata SUDAH ganti password (is_default == 0), usir mereka ke halaman utama
if ($data_user['is_default'] == 0) {
    header("Location: index.php");
    exit();
}

// 3. Proses Update Password
if (isset($_POST['update_password'])) {
    $pass_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if ($pass_baru !== $konfirmasi) {
        $error = "Konfirmasi password baru tidak cocok!";
    } elseif (strlen($pass_baru) < 6) {
        $error = "Password minimal harus 6 karakter!";
    } elseif ($pass_baru === 'rahasia123') { 
        $error = "Anda tidak boleh menggunakan password bawaan kembali!";
    } else {
        // Enkripsi password baru
        $pass_aman = password_hash($pass_baru, PASSWORD_DEFAULT);
        
        // UPDATE PASSWORD & SET is_default MENJADI 0
        $query_update = "UPDATE users SET password = '$pass_aman', is_default = 0 WHERE username = '$username_sekarang'";
        
        if (mysqli_query($con, $query_update)) {
            echo "<script>
                    alert('Password berhasil diperbarui! Selamat menggunakan aplikasi.'); 
                    window.location.href='index.php';
                  </script>";
            exit();
        } else {
            $error = "Gagal memperbarui password database!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wajib Ganti Password</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
            width: 100%;
            max-width: 400px;
        }

        .header {
            text-align: center;
            margin-bottom: 25px;
        }

        .header h3 {
            color: #333333;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .header p {
            color: #7f8c8d;
            font-size: 13px;
            line-height: 1.5;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555555;
            font-size: 14px;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #dddddd;
            border-radius: 8px;
            font-size: 15px;
            color: #333333;
            outline: none;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            border-color: #4a90e2;
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.15);
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background-color: #2ecc71; 
            border: none;
            border-radius: 8px;
            color: #ffffff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 10px;
        }

        .btn-submit:hover {
            background-color: #27ae60;
        }

        .error-message {
            background-color: #ffebee;
            color: #c62828;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 20px;
            border-left: 4px solid #ef5350;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="header">
            <h3>Ganti Password Baru</h3>
            <p>Demi keamanan, akun dengan password bawaan atau habis di-reset wajib memperbarui password sebelum masuk.</p>
        </div>

        <?php if(isset($error)): ?>
            <div class="error-message">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" onsubmit="return validasiForm()">
            <div class="form-group">
                <label for="password_baru">Password Baru</label>
                <input type="password" id="password_baru" name="password_baru" placeholder="Minimal 6 karakter" required>
            </div>

            <div class="form-group">
                <label for="konfirmasi_password">Konfirmasi Password Baru</label>
                <input type="password" id="konfirmasi_password" name="konfirmasi_password" placeholder="Ulangi password baru" required>
            </div>

            <button type="submit" name="update_password" class="btn-submit">Simpan & Masuk Aplikasi</button>
        </form>
    </div>

    <script>
    function validasiForm() {
        var p1 = document.getElementById('password_baru').value;
        var p2 = document.getElementById('konfirmasi_password').value;

        if (p1 !== p2) {
            alert("Konfirmasi password baru tidak cocok!");
            return false;
        }
        if (p1.length < 6) {
            alert("Password minimal harus 6 karakter!");
            return false;
        }
        if (p1 === 'rahasia123') {
            alert("Anda tidak boleh menggunakan password bawaan kembali!");
            return false;
        }
        return confirm("Apakah Anda yakin data password sudah benar? Pastikan Anda mengingatnya.");
    }
    </script>
</body>
</html>
