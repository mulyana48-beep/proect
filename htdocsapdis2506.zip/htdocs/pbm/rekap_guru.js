// 1. Mengubah seluruh baris sel data guru menjadi input serentak
function aktifkanModeEditGuru() {
    document.querySelectorAll('.baris-guru').forEach(baris => {
        const cMapel = baris.querySelector('.edit-mapel');
        const cNama = baris.querySelector('.edit-nama');
        const cTingkat = baris.querySelector('.edit-tingkat');
        const cPassed = baris.querySelector('.edit-passed');
        const cTugas = baris.querySelector('.edit-tugas');
        const cKosong = baris.querySelector('.edit-kosong');

        // Menggunakan getAttribute('data-asli') agar mengambil nilai murni dari database
        cMapel.innerHTML = `<input type="text" class="input-inline" value="${cMapel.getAttribute('data-asli')}">`;
        cNama.innerHTML = `<input type="text" class="input-inline" value="${cNama.getAttribute('data-asli')}">`;
        cTingkat.innerHTML = `<input type="text" class="input-inline text-center-input" value="${cTingkat.getAttribute('data-asli')}">`;

        // SOLUSI MUTLAK: Mengambil angka murni langsung dari atribut data-asli
        cPassed.innerHTML = `<input type="number" class="input-inline text-center-input" value="${cPassed.getAttribute('data-asli')}">`;
        cTugas.innerHTML = `<input type="number" class="input-inline text-center-input" value="${cTugas.getAttribute('data-asli')}">`;
        cKosong.innerHTML = `<input type="number" class="input-inline text-center-input" value="${cKosong.getAttribute('data-asli')}">`;
    });

    document.getElementById('btnMode').style.display = 'none';
    document.getElementById('btnBatal').style.display = 'inline-block';
    document.getElementById('btnSimpan').style.display = 'inline-block';
}

// 2. Membatalkan pengeditan dan mengembalikan struktur badge semula
function batalEditGuru() {
    document.querySelectorAll('.baris-guru').forEach(baris => {
        const cMapel = baris.querySelector('.edit-mapel');
        const cNama = baris.querySelector('.edit-nama');
        const cTingkat = baris.querySelector('.edit-tingkat');
        const cPassed = baris.querySelector('.edit-passed');
        const cTugas = baris.querySelector('.edit-tugas');
        const cKosong = baris.querySelector('.edit-kosong');

        cMapel.innerHTML = cMapel.getAttribute('data-asli');
        cNama.innerHTML = cNama.getAttribute('data-asli');
        cTingkat.innerHTML = `<span class="badge-tingkat">Kelas ${cTingkat.getAttribute('data-asli')}</span>`;
        
        // Dikembalikan menggunakan akhiran ' JP' sesuai dengan format tampilan awal di PHP Anda
        cPassed.innerHTML = `<span class="badge badge-passed">${cPassed.getAttribute('data-asli')} JP</span>`;
        cTugas.innerHTML = `<span class="badge badge-tugas">${cTugas.getAttribute('data-asli')} JP</span>`;
        cKosong.innerHTML = `<span class="badge badge-kosong">${cKosong.getAttribute('data-asli')} JP</span>`;
    });

    document.getElementById('btnMode').style.display = 'inline-block';
    document.getElementById('btnBatal').style.display = 'none';
    document.getElementById('btnSimpan').style.display = 'none';
}

// 3. Mengemas matriks input baris dan mengirim paket massal JSON ke PHP
function simpanPerubahanGuru() {
    const semuaBaris = document.querySelectorAll('.baris-guru');
    let dataPaketGuru = [];

    semuaBaris.forEach(baris => {
        const kode = baris.getAttribute('data-kode');
        const mapel = baris.querySelector('.edit-mapel input').value.trim();
        const nama_guru = baris.querySelector('.edit-nama input').value.trim();
        const tingkat = baris.querySelector('.edit-tingkat input').value.trim();
        const passed = baris.querySelector('.edit-passed input').value.trim();
        const tugas = baris.querySelector('.edit-tugas input').value.trim();
        const kosong = baris.querySelector('.edit-kosong input').value.trim();

        dataPaketGuru.push({ kode, mapel, nama_guru, tingkat, passed, tugas, kosong });
    });

    fetch('update_global_guru.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_guru: dataPaketGuru })
    })
    .then(response => response.json())
    .then(hasil => {
        if (hasil.status === 'success') {
            semuaBaris.forEach(baris => {
                const cMapel = baris.querySelector('.edit-mapel');
                const cNama = baris.querySelector('.edit-nama');
                const cTingkat = baris.querySelector('.edit-tingkat');
                const cPassed = baris.querySelector('.edit-passed');
                const cTugas = baris.querySelector('.edit-tugas');
                const cKosong = baris.querySelector('.edit-kosong');

                const vMapel = cMapel.querySelector('input').value.trim();
                const vNama = cNama.querySelector('input').value.trim();
                const vTingkat = cTingkat.querySelector('input').value.trim();
                const vPassed = cPassed.querySelector('input').value.trim();
                const vTugas = cTugas.querySelector('input').value.trim();
                const vKosong = cKosong.querySelector('input').value.trim();

                cMapel.innerHTML = vMapel; cMapel.setAttribute('data-asli', vMapel);
                cNama.innerHTML = vNama; cNama.setAttribute('data-asli', vNama);
                cTingkat.innerHTML = `<span class="badge-tingkat">Kelas ${vTingkat}</span>`; cTingkat.setAttribute('data-asli', vTingkat);
                
                // Disimpan kembali ke tampilan layar menggunakan akhiran ' JP' agar konsisten
                cPassed.innerHTML = `<span class="badge badge-passed">${vPassed} JP</span>`; cPassed.setAttribute('data-asli', vPassed);
                cTugas.innerHTML = `<span class="badge badge-tugas">${vTugas} JP</span>`; cTugas.setAttribute('data-asli', vTugas);
                cKosong.innerHTML = `<span class="badge badge-kosong">${vKosong} JP</span>`; cKosong.setAttribute('data-asli', vKosong);
            });

            document.getElementById('btnMode').style.display = 'inline-block';
            document.getElementById('btnBatal').style.display = 'none';
            document.getElementById('btnSimpan').style.display = 'none';
            alert('Sukses! Semua data guru dan akumulasi statistik berhasil diperbarui.');
        } else {
            alert('Gagal menyimpan: ' + hasil.message);
        }
    }).catch(error => console.error('Error:', error));
}

// 4. Fitur pencarian instan bawaan Anda
function fiturCari() {
    var input, filter, table, tr, tdGuru, tdMapel, i, txtValueGuru, txtValueMapel;
    input = document.getElementById("inputCari"); filter = input.value.toUpperCase();
    table = document.getElementById("tabelGuru"); tr = table.getElementsByTagName("tr");
    for (i = 1; i < tr.length; i++) {
        tdMapel = tr[i].getElementsByTagName("td")[1]; // Ditentukan indeks kolomnya agar pencarian akurat
        tdGuru = tr[i].getElementsByTagName("td")[2]; 
        if (tdMapel || tdGuru) {
            txtValueMapel = tdMapel.textContent || tdMapel.innerText; txtValueGuru = tdGuru.textContent || tdGuru.innerText;
            if (txtValueMapel.toUpperCase().indexOf(filter) > -1 || txtValueGuru.toUpperCase().indexOf(filter) > -1) { tr[i].style.display = ""; } else { tr[i].style.display = "none"; }
        }       
    }
}
