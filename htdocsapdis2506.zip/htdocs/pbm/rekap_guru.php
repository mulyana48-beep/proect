<?php 
include 'header.php'; 
include 'config.php'; 
if ($_SESSION['level_user'] !== 'admin') {
    echo "<script>alert('Akses Khusus Admin!'); window.location.href='form.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekapitulasi KBM Per Guru & Mapel</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; }
body { background-color: #f4f6f9; color: #333; }

        .main-content {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 5px 20px;
            width: 100%;
        }
.rekap-container { background: #fff; padding: 2px; border-radius: 0; box-shadow: 0 0 0 rgba(0,0,0,0.05); width: 100%; max-width: 1366px; }
.header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: auto; gap: 5px; flex-wrap: wrap; }
h2 { color: #2c3e50; font-size: 24px; font-weight: 600; }

.search-box { padding: 10px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; width: 250px; outline: none; transition: 0.2s; }
.search-box:focus { border-color: #4a90e2; }

/* Tombol Kendali Mode */
.btn { padding: 10px 20px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 14px; transition: 0.2s; }
.btn-mode-edit { background-color: #3498db; color: white; }
.btn-mode-edit:hover { background-color: #2980b9; }
.btn-simpan-semua { background-color: #2ecc71; color: white; display: none; }
.btn-simpan-semua:hover { background-color: #27ae60; }
.btn-batal { background-color: #95a5a6; color: white; display: none; margin-right: 10px; }
.btn-batal:hover { background-color: #7f8c8d; }

.table-responsive { width: 100%; overflow-x: auto; margin-top: 15px; border-radius: 0; border: 1px solid #eef2f5; }
table { width: 100%; border-collapse: collapse; background: #fff; }

/* Penguncian Padding Tipis 1px */
th, td { padding: 1px 4px !important; text-align: left; border-bottom: 1px solid #eef2f5; font-size: 14px; }
th { background-color: #2c3e50; color: white; font-weight: 600; text-transform: uppercase; font-size: 13px; padding: 12px 15px !important; }
tr:hover { background-color: #f8fafd; }

/* Desain Kotak Input Tipis 1px Dalam Mode Edit */
.input-inline { width: 100%; padding: 1px 4px !important; margin: 0 !important; height: 26px; line-height: 24px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; outline: none; box-sizing: border-box; }
.input-inline:focus { border-color: #3498db; background-color: #fff; }
.text-center-input { text-align: center; }

/* Komponen Badge */
.badge { padding: 4px 10px; border-radius: 12px; font-weight: bold; font-size: 13px; display: inline-block; text-align: center; min-width: 65px; }
.badge-passed { background-color: #e8f5e9; color: #2e7d32; }
.badge-tugas { background-color: #fff3e0; color: #ef6c00; }
.badge-kosong { background-color: #ffebee; color: #c62828; }
.badge-tingkat { background-color: #ebf5fb; color: #2980b9; border: 1px solid #d4e6f1; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; display: inline-block; }

.nav-links { display: flex; gap: 20px; margin-top: 25px; }
.nav-link { color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 14px; }
.nav-link:hover { text-decoration: underline; }
.info-kosong { text-align: center; color: #7f8c8d; padding: 40px; font-style: italic; }

@media (max-width: 768px) { 
    .header-section { flex-direction: column; align-items: stretch; gap: 2px; } 
    .search-box { width: 100%; } 
    .nav-links { flex-direction: column; gap: 10px; } 
}
    </style>
</head>
<body>

<div class="main-content">
    <div class="rekap-container">
        
        <div class="header-section">
            <h2>Rekapitulasi KBM Per Guru & Mata Pelajaran</h2>
            <div>
                <button type="button" id="btnBatal" class="btn btn-batal" onclick="batalEditGuru()">Batal</button>
                <button type="button" id="btnMode" class="btn btn-mode-edit" onclick="aktifkanModeEditGuru()">Mode Edit</button>
                <button type="button" id="btnSimpan" class="btn btn-simpan-semua" onclick="simpanPerubahanGuru()">Simpan Semua</button>
            </div>
        </div>
        
        <?php
        $query_guru = "SELECT kode, mapel, nama_guru, tingkat, passed, tugas, kosong FROM mapel_guru ORDER BY kode ASC";
        $eksekusi_guru = mysqli_query($con, $query_guru);
        if ($eksekusi_guru && mysqli_num_rows($eksekusi_guru) > 0): 
        ?>
            <div class="table-responsive">
                <table id="tabelGuru">
<thead>
    <tr>
        <th style="width: 5%; text-align: center;">No</th> <!-- Kolom No Baru -->
        <th style="width: 10%;">Kode</th>
        <th style="width: 25%;">Mata Pelajaran</th>
        <th style="width: 25%;">Nama Guru</th>
        <th style="width: 12%; text-align: center;">Tingkat</th>
        <th style="text-align: center; width: 10%;">Passed (P)</th>
        <th style="text-align: center; width: 10%;">Tugas (T)</th>
        <th style="text-align: center; width: 8%;">Kosong (K)</th>
    </tr>
</thead>

<tbody>
    <?php 
    $no = 1; // 1. Inisialisasi angka nomor awal sebelum looping
    while ($row = mysqli_fetch_assoc($eksekusi_guru)): 
    ?>
        <tr class="baris-guru" data-kode="<?php echo htmlspecialchars($row['kode']); ?>">
            <!-- 2. Cetak nomor urut otomatis ke bawah -->
            <td style="text-align: center; color: #7f8c8d; font-weight: 500;">
                <?php echo $no++; ?>
            </td>

            <td style="font-weight: bold; color: #7f8c8d; padding-left: 15px !important;"><?php echo htmlspecialchars($row['kode']); ?></td>
            <td class="edit-mapel" data-asli="<?php echo htmlspecialchars($row['mapel']); ?>" style="font-weight: 600; color: #2c3e50;"><?php echo htmlspecialchars($row['mapel']); ?></td>
            <td class="edit-nama" data-asli="<?php echo htmlspecialchars($row['nama_guru']); ?>"><?php echo htmlspecialchars($row['nama_guru']); ?></td>
            <td class="edit-tingkat" data-asli="<?php echo htmlspecialchars($row['tingkat']); ?>" style="text-align: center;">
                <span class="badge-tingkat">Kelas <?php echo htmlspecialchars($row['tingkat']); ?></span>
            </td>
            <td class="edit-passed" data-asli="<?php echo $row['passed']; ?>" style="text-align: center;"><span class="badge badge-passed"><?php echo $row['passed']; ?> JP</span></td>
            <td class="edit-tugas" data-asli="<?php echo $row['tugas']; ?>" style="text-align: center;"><span class="badge badge-tugas"><?php echo $row['tugas']; ?> JP</span></td>
            <td class="edit-kosong" data-asli="<?php echo $row['kosong']; ?>" style="text-align: center;"><span class="badge badge-kosong"><?php echo $row['kosong']; ?> JP</span></td>
        </tr>
    <?php endwhile; ?>
</tbody>

                </table>
            </div>
        <?php else: ?>
            <p class="info-kosong">Belum ada data mata pelajaran dan guru yang terdaftar di database.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Memanggil Berkas JavaScript Eksternal -->
<script src="rekap_guru.js"></script>
</body>
</html>
