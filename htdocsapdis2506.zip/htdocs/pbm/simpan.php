<?php
// 1. Ubah pelapor error ke mode normal agar mencetak error teks (bukan Error 500)
mysqli_report(MYSQLI_REPORT_OFF); 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php'; // Menggunakan variabel koneksi $con

// Fungsi mendapatkan nama hari kecil (senin, selasa, dst)
function hitungHariIndo($tgl) {
    $daftar_hari = array('minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu');
    $indeks = date('w', strtotime($tgl));
    return $daftar_hari[$indeks];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Tangkap data utama dari form
    $tanggal = mysqli_real_escape_string($con, $_POST['tanggal']);
    $kelas   = mysqli_real_escape_string($con, $_POST['kelas']); 
    $hari    = hitungHariIndo($tanggal);

    // Validasi jika kelas kosong
    if (empty($kelas) || trim($kelas) == "") {
        echo "<script>
                alert('Gagal Menyimpan! Kode Kelas Anda tidak ditemukan di database.');
                window.location.href='form.php';
              </script>";
        exit();
    }

    // =========================================================================
    // 2. VALIDASI CEK DUPLIKASI DATA (TANGGAL & KELAS YANG SAMA)
    // =========================================================================
    $query_cek_duplikat = "SELECT COUNT(*) AS total FROM catat WHERE tanggal = '$tanggal' AND kelas = '$kelas'";
    $eksekusi_cek = mysqli_query($con, $query_cek_duplikat);
    $data_duplikat = mysqli_fetch_assoc($eksekusi_cek);

    if ($data_duplikat['total'] > 0) {
        echo "<script>
                alert('Gagal Menyimpan! Kelas Anda sudah mengirimkan jurnal untuk tanggal ini.');
                window.location.href='form.php';
              </script>";
        exit(); // Hentikan script total agar tidak terjadi double input
    }
    // =========================================================================

    $jam = [];
    $sjam = [];
    
    // 2. Mulai Perulangan Jam ke-01 sampai Jam ke-10
    for ($i = 1; $i <= 10; $i++) {
        $num = sprintf("%02d", $i);
        
        // Tangkap status radio button pita (P/T/K) -> Boleh kosong
        $sjam[$num] = isset($_POST["sjam_ke_$num"]) ? trim($_POST["sjam_ke_$num"]) : '';
        
        // Buat kriteria gabungan hari_jam (misal: senin_01)
        $kriteria_hari_jam = $hari . "_" . $num;

        // Ambil nama mapel dari tabel jadwal sesuai kolom kelas yang diinput
        $query_jdl = "SELECT `$kelas` AS mapel FROM jadwal WHERE hari_jam = '$kriteria_hari_jam' LIMIT 1";
        $eksekusi_jdl = mysqli_query($con, $query_jdl);

        // Validasi query agar tidak memicu Fatal Error jika nama kolom tidak ditemukan
        if ($eksekusi_jdl && mysqli_num_rows($eksekusi_jdl) > 0) {
            $data_jdl = mysqli_fetch_assoc($eksekusi_jdl);
            $jam[$num] = trim($data_jdl['mapel']); 
        } else {
            $jam[$num] = ""; 
        }

        // -----------------------------------------------------------------
        // SKENARIO UPDATE TABEL REKAP KELAS MAPEL (OTOMATISASI METODE BARIS)
        // -----------------------------------------------------------------
        $kode_mapel = mysqli_real_escape_string($con, $jam[$num]); 
        $status_jam = $sjam[$num]; 

        // PENGAMAN UTAMA: Jika mapel kosong, lewati semua proses update rekap database
        if (!empty($kode_mapel)) {
            
            $kolom_target = "";
            if ($status_jam == "P") { $kolom_target = "passed"; } 
            elseif ($status_jam == "T") { $kolom_target = "tugas"; } 
            elseif ($status_jam == "K") { $kolom_target = "kosong"; }

            // LANGKAH B: Cek keberadaan baris di tabel rekap_kelas_mapel
            $sql_cek_rekap = "SELECT id_rekap FROM rekap_kelas_mapel 
                              WHERE kode_kolom_kelas = '$kelas' AND kode_mapel = '$kode_mapel' LIMIT 1";
            $eksekusi_cek = mysqli_query($con, $sql_cek_rekap);

            if ($eksekusi_cek && mysqli_num_rows($eksekusi_cek) == 0) {
                $sql_insert_rekap = "INSERT INTO rekap_kelas_mapel (kode_kolom_kelas, kode_mapel, passed, tugas, kosong) 
                                     VALUES ('$kelas', '$kode_mapel', 0, 0, 0)";
                mysqli_query($con, $sql_insert_rekap);
            }

            // PENGAMAN KEDUA: Update angka rekap (+1) HANYA jika status_jam diisi P/T/K
            if (!empty($kolom_target)) {
                // LANGKAH A: Update ke tabel global mapel_guru
                $sql_update_mapel = "UPDATE mapel_guru SET `$kolom_target` = `$kolom_target` + 1 WHERE `kode` = '$kode_mapel'";
                mysqli_query($con, $sql_update_mapel);

                // LANGKAH C: Eksekusi akumulasi (+1) ke rekap_kelas_mapel
                $sql_update_rekap_kelas = "UPDATE rekap_kelas_mapel 
                                           SET `$kolom_target` = `$kolom_target` + 1 
                                           WHERE kode_kolom_kelas = '$kelas' AND kode_mapel = '$kode_mapel'";
                mysqli_query($con, $sql_update_rekap_kelas);
            }
        }
    } // Akhir perulangan FOR utama

    // Pembersihan string array sebelum masuk ke tabel harian catat
    for ($i = 1; $i <= 10; $i++) {
        $num = sprintf("%02d", $i);
        $jam[$num] = mysqli_real_escape_string($con, $jam[$num]);
        $sjam[$num] = mysqli_real_escape_string($con, $sjam[$num]);
    }

    // 3. Query INSERT ke tabel harian 'catat'
    $sql_insert = "INSERT INTO catat (
                tanggal, kelas, 
                jam_ke_01, sjam_ke_01, jam_ke_02, sjam_ke_02, 
                jam_ke_03, sjam_ke_03, jam_ke_04, sjam_ke_04, 
                jam_ke_05, sjam_ke_05, jam_ke_06, sjam_ke_06, 
                jam_ke_07, sjam_ke_07, jam_ke_08, sjam_ke_08, 
                jam_ke_09, sjam_ke_09, jam_ke_10, sjam_ke_10
            ) VALUES (
                '$tanggal', '$kelas', 
                '{$jam['01']}', '{$sjam['01']}', '{$jam['02']}', '{$sjam['02']}', 
                '{$jam['03']}', '{$sjam['03']}', '{$jam['04']}', '{$sjam['04']}', 
                '{$jam['05']}', '{$sjam['05']}', '{$jam['06']}', '{$sjam['06']}', 
                '{$jam['07']}', '{$sjam['07']}', '{$jam['08']}', '{$sjam['08']}', 
                '{$jam['09']}', '{$sjam['09']}', '{$jam['10']}', '{$sjam['10']}'
            )";

    if (mysqli_query($con, $sql_insert)) {
        echo "<script>
                alert('Skenario Sinkronisasi Berhasil! Jurnal Harian & Rekap Tabel Kelas Terupdate.');
                window.location.href='riwayat.php';
              </script>";
        exit();
    } else {
        die("Gagal menyimpan log harian ke tabel catat. Error SQL: " . mysqli_error($con));
    }
} else {
    header("Location: form.php");
    exit();
}
?>
