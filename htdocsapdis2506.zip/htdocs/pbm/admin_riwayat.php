<?php
include "header.php"; 
include "config.php"; 

// Proteksi Tambahan: Hanya level admin yang boleh membuka halaman ini
if (!isset($_SESSION['level_user']) || $_SESSION['level_user'] !== 'admin') {
    echo "<script>alert('Akses Khusus Admin!'); window.location.href='form.php';</script>";
    exit();
}

// Fungsi mendapatkan nama hari kecil (senin, selasa, dst) berdasarkan format tanggal
function hitungHariIndo($tgl) {
    $daftar_hari = array('Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu');
    $indeks = date('w', strtotime($tgl));
    return $daftar_hari[$indeks];
}

// QUERY UTAMA ADMIN: Menggabungkan tabel 'catat' dengan 'master_kelas' menggunakan INNER JOIN
// Menampilkan kolom nama_kelas asli, diurutkan berdasarkan tanggal terbaru
$query_admin_riwayat = "SELECT c.*, mk.nama_kelas AS nama_kelas_asli 
                        FROM catat c
                        INNER JOIN master_kelas mk ON c.kelas = mk.kode_kelas 
                        ORDER BY c.dibuat_pada DESC";

$result_riwayat = mysqli_query($con, $query_admin_riwayat);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin - Riwayat Semua Jurnal</title>
    <style>
		* { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f6f9; color: #333; padding: 0; }
        .container { max-width: 100%; margin: 1px 0 auto; background: #fff; padding: 25px; border-radius: 0; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        h2 { color: #2c3e50; margin-bottom: 5px; }
        .sub-title { color: #7f8c8d; font-size: 14px; margin-bottom: 25px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 12px 15px; text-align: center; border-bottom: 1px solid #eef2f5; }
        th { background-color: #2c3e50; color: white; font-weight: 600; }
        tr:hover { background-color: #fcfcfc; }
        /* Badge Status Bulat */
        .badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; color: white; display: inline-block; min-width: 25px; }
        .badge-p { background-color: #4a90e2; }
        .badge-t { background-color: #f39c12; }
        .badge-k { background-color: #e74c3c; }
        .badge-kosong { background-color: #bdc3c7; color: #333; }
        .alert-info { background-color: #e8f4fd; color: #2b73b6; padding: 15px; border-radius: 8px; text-align: center; font-weight: 500; }
    </style>
</head>
<body>

<div class="container">
    <h2>Monitoring Riwayat Pelaporan Semua Kelas</h2>
    <div class="sub-title">Halaman khusus panel Admin untuk memantau rekap pengiriman seluruh kelas</div>

    <div class="table-responsive">
        <?php if ($result_riwayat && mysqli_num_rows($result_riwayat) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <!-- Menambahkan 4 kolom kontrol awal versi admin, di-span vertikal -->
                        <th rowspan="2" style="vertical-align: middle; width: 50px;">No</th>
                        <th rowspan="2" style="vertical-align: middle; width: 100px;">Hari</th>
                        <th rowspan="2" style="vertical-align: middle; width: 110px;">Tanggal</th>
                        <th rowspan="2" style="vertical-align: middle; width: 120px;">Nama Kelas</th>
                        <th colspan="10">Status Pembelajaran per Jam</th>
                    </tr>
                    <tr>
                        <?php for($j=1; $j<=10; $j++) echo "<th>".sprintf("%02d", $j)."</th>"; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1; // Inisialisasi nomor baris awal
                    while ($row = mysqli_fetch_assoc($result_riwayat)): 
                        $nama_hari = hitungHariIndo($row['tanggal']); // Ambil hari dari kolom tanggal baris tersebut
                    ?>
                        <tr>
                            <!-- Kolom 1: Nomor Urut -->
                            <td style="color: #7f8c8d; font-weight: 500;"><?php echo $no++; ?></td>
                            
                            <!-- Kolom 2: Hari -->
                            <td style="font-weight: 500; color: #34495e;"><?php echo $nama_hari; ?></td>
                            
                            <!-- Kolom 3: Tanggal -->
                            <td style="font-weight: 600; color: #2c3e50;">
                                <?php echo date('d-m-Y', strtotime($row['tanggal'])); ?>
                            </td>
                            
                            <!-- Kolom 4: Nama Kelas Asli (Hasil Sinkronisasi Relasi JOIN) -->
                            <td style="font-weight: bold; color: #2ecc71;">
                                <?php echo htmlspecialchars($row['nama_kelas_asli']); ?>
                            </td>
                            
                            <!-- Looping Tampilan Kolom sjam_ke_01 sampai sjam_ke_10 -->
                            <?php for ($i = 1; $i <= 10; $i++): 
                                $num = sprintf("%02d", $i);
                                $status = $row["sjam_ke_$num"];
                                $mapel = htmlspecialchars($row["jam_ke_$num"]);
                                
                                // Tentukan warna badge berdasarkan huruf status
                                $class_badge = "badge-kosong";
                                if ($status == "P") { $class_badge = "badge-p"; }
                                elseif ($status == "T") { $class_badge = "badge-t"; }
                                elseif ($status == "K") { $class_badge = "badge-k"; }
                            ?>
                                <td>
                                    <?php if (!empty($mapel)): ?>
                                        <!-- Huruf ringkas status dengan title hover nama mapel asli -->
                                        <span class="badge <?php echo $class_badge; ?>" title="Mata Pelajaran: <?php echo $mapel; ?>">
                                            <?php echo !empty($status) ? $status : '-'; ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ccc;">-</span>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert-info">Belum ada rekap pengiriman jurnal dari kelas manapun di database.</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
