<?php
date_default_timezone_set("Asia/Jakarta");
$server = "sql313.infinityfree.com";
$username = "if0_42098070";
$password = "t9CiuhUJkw2vKp";
$database = "if0_42098070_kbm";

$con = mysqli_connect($server, $username, $password, $database);

// Periksa koneksi
if (!$con) {
    die("Koneksi dengan database gagal: " . mysqli_connect_error());
}

// Set charset ke UTF-8 untuk menghindari masalah karakter
mysqli_set_charset($con, "utf8mb4");
?>
